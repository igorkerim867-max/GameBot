
from games.mafia.views import PlayerSelectView
import random
import asyncio
from games.room_manager import room_manager
import discord
from games.mafia.engine.check_win import check_win
from games.mafia.actions.doctor import handle_doctor_action
from games.mafia.actions.sheriff import handle_sheriff_action
from games.mafia.player import MafiaPlayer
from games.mafia.role_manager import ROLES
from games.mafia.roles import RoleType
from games.mafia.services.player_service import PlayerService
from games.mafia.services.message_service import MessageService
from games.mafia.engine.start_night import start_night
from games.mafia.night_state import NightState
class MafiaGame:

    def __init__(self, bot: discord.Client, room):

        self.bot = bot
        self.room = room

        self.players = [
            MafiaPlayer(user_id)
            for user_id in room.players
        ]

        self.day = 0
        self.night = 0

        self.started = False

        # Игровое сообщение
        self.game_message = None
        self.game_channel = None
        # Ночные действия
        self.night_state = NightState()
        # Голосование
        self.votes = {}
        self.voted_players = set()

    async def start(self):

        print("========== GAME START ==========")

        self.started = True

        self.give_roles()

        await self.send_roles()

        await self.create_game_message()
        await self.start_night()

        print("========== GAME READY ==========")

    def give_roles(self):

        count = len(self.players)

        role_types = []

        if count == 4:
            role_types = [
                RoleType.MAFIA,
                RoleType.DOCTOR,
                RoleType.SHERIFF,
                RoleType.CIVILIAN
            ]

        elif count == 5:
            role_types = [
                RoleType.MAFIA,
                RoleType.DOCTOR,
                RoleType.SHERIFF,
                RoleType.HOOKER,
                RoleType.CIVILIAN
    ]

        elif count == 6:
            role_types = [
                RoleType.MAFIA,
                RoleType.MANIAC,
                RoleType.DOCTOR,
                RoleType.SHERIFF,
                RoleType.CIVILIAN,
                RoleType.CIVILIAN
            ]

        else:

            role_types = [
                RoleType.DON,
                RoleType.MAFIA,
                RoleType.DOCTOR,
                RoleType.SHERIFF,
                RoleType.MANIAC
            ]

            while len(role_types) < count:
                role_types.append(RoleType.CIVILIAN)

        random.shuffle(role_types)

        for player, role_type in zip(self.players, role_types):
            player.role = ROLES[role_type]

    async def send_roles(self):

        print("Отправка ролей...")

        for player in self.players:

            try:
                user = await self.bot.fetch_user(player.user_id)

                await user.send(
                    f"🎭 Ваша роль: **{player.role.name}**"
                )

                print(f"✔ Роль отправлена {user}")

            except Exception as e:
                print(f"Не удалось отправить роль {player.user_id}: {e}")


    async def create_game_message(self):

        if self.room.channel_id is None:
            return

        channel = self.bot.get_channel(self.room.channel_id)

        if channel is None:
            try:
                channel = await self.bot.fetch_channel(
                    self.room.channel_id
                )
            except Exception:
                return

        self.game_channel = channel

        embed = discord.Embed(
            title="🎭 Мафия",
            description=(
                "🌙 **Ночь 1**\n\n"
                "Все роли получили свои карты.\n"
                "Ожидаем действия игроков..."
            ),
            color=discord.Color.dark_blue()
        )

        self.game_message = await channel.send(
            embed=embed
        )


    async def update_game_message(
        self,
        title: str,
        description: str,
        color: discord.Color = discord.Color.blurple()
    ):

        if self.game_message is None:
            return

        embed = discord.Embed(
            title=title,
            description=description,
            color=color
        )

        await self.game_message.edit(
            embed=embed
        )

    def get_player(self, user_id):
        return PlayerService.get_player(self, user_id)


    def alive_players(self):
        return PlayerService.alive_players(self)


    def mafia_players(self):
        return PlayerService.mafia_players(self)


    def civilians(self):
        return PlayerService.civilians(self)

    async def start_night(self):
        return await start_night(self)
    async def mafia_action(
        self,
        interaction,
        actor,
        target_id
    ):
        target = self.get_player(target_id)

        if target is None or not target.alive:
            await interaction.response.send_message(
                "❌ Этот игрок уже мёртв.",
                ephemeral=True
            )
            return

        # Если ход делает Дон — его выбор всегда главный
        if actor.role.role_type == RoleType.DON:
            self.mafia_target = target_id

        # Если Дон жив, обычная мафия не может изменить его выбор
        else:
            don_alive = any(
                p.alive and p.role.role_type == RoleType.DON
                for p in self.players
            )

            if not don_alive:
                self.mafia_target = target_id

        self.mafia_done = True

        print(f"{actor.role.name} выбрал {target_id}")

        await interaction.response.send_message(
            "🔫 Выбор сохранён.",
            ephemeral=True
        )
        await self.check_night_finished()


    async def doctor_action(
        self,
        interaction,
        actor,
        target_id
    ):
        await handle_doctor_action(self, interaction, actor, target_id)
    async def sheriff_action(
       self,
       interaction,
       actor,
       target_id
    ):
        return await handle_sheriff_action(
           self,
           interaction,
           actor,
           target_id
       )
    async def hooker_action(
        self,
        interaction,
        actor,
        target_id
    ):
        target = self.get_player(target_id)

        if target is None or not target.alive:
            await interaction.response.send_message(
                "❌ Этот игрок уже мёртв.",
                ephemeral=True
            )
            return

        if actor.user_id == target.user_id:
            await interaction.response.send_message(
                "❌ Нельзя выбрать себя.",
                ephemeral=True
            )
            return

        if self.hooker_done:
            await interaction.response.send_message(
                "❌ Вы уже сделали свой ход.",
                ephemeral=True
            )
            return

        self.hooker_target = target_id
        self.hooker_done = True

        target.can_vote = False
        target.blocked_by_hooker = True

        await interaction.response.send_message(
            (
                "💋 Вы посетили выбранного игрока.\n\n"
                "Сегодня он не сможет участвовать в голосовании."
            ),
            ephemeral=True
        )

        await self.check_night_finished()
    async def maniac_action(
        self,
        interaction,
        actor,
        target_id
    ):
        target = self.get_player(target_id)

        if target is None or not target.alive:
            await interaction.response.send_message(
                "❌ Этот игрок уже мёртв.",
                ephemeral=True
            )
            return

        if self.maniac_done:
            await interaction.response.send_message(
                "❌ Вы уже сделали свой ход.",
                ephemeral=True
            )
            return

        self.maniac_target = target_id
        self.maniac_done = True

        print(f"Маньяк выбрал {target_id}")

        await interaction.response.send_message(
            "🔪 Выбор сохранён.",
            ephemeral=True
        )

        await self.check_night_finished()
    async def check_night_finished(self):
        mafia_ready = self.night_state.mafia_done or len(self.mafia_players()) == 0
        doctor_ready = self.night_state.doctor_done or not any(
            p.role.role_type == RoleType.DOCTOR and p.alive
            for p in self.players
        )
        sheriff_ready = self.night_state.sheriff_done or not any(
            p.role.role_type == RoleType.SHERIFF and p.alive
            for p in self.players
        )
        hooker_ready = self.night_state.hooker_done or not any(
            p.role.role_type == RoleType.HOOKER and p.alive
            for p in self.players
        )
        maniac_ready = self.night_state.maniac_done or not any(
            p.role.role_type == RoleType.MANIAC and p.alive
            for p in self.players
        )

        if (
            mafia_ready
            and doctor_ready
            and sheriff_ready
            and hooker_ready
            and maniac_ready
        ):
         await self.finish_night()

    async def finish_night(self):

        print("Ночь закончилась")

        dead_players = []

        maniac_dead = None

        hooker = next(
            (
                p for p in self.players
                if p.role.role_type == RoleType.HOOKER and p.alive
            ),
            None
        )

        hooker_target = None

        if hooker and self.hooker_target is not None:
            hooker_target = self.get_player(self.hooker_target)

        # Если мафия кого-то выбрала
        if self.mafia_target is not None:

            # Доктор спас игрока
            if self.mafia_target == self.doctor_target:

                doctor = next(
                    (
                        p for p in self.players
                        if p.role.role_type == RoleType.DOCTOR and p.alive
                    ),
                    None
                )

                if doctor:
                    user = await self.bot.fetch_user(doctor.user_id)
                    await user.send(
                        "✅ Вы успешно спасли игрока этой ночью!"
                    )

                for mafia in self.mafia_players():
                    mafia_user = await self.bot.fetch_user(mafia.user_id)
                    await mafia_user.send(
                        "🩺 Доктор спас выбранную вами жертву.\n"
                        "❌ Убийство не удалось."
                    )

            else:

                dead_player = self.get_player(self.mafia_target)

                if dead_player:

                    dead_player.alive = False

                    dead_players.append(dead_player)

                    user = await self.bot.fetch_user(dead_player.user_id)

                    await user.send(
        "💀 Вы были убиты этой ночью.\n"
        "Вы больше не участвуете в игре."
                    )

                # Если убили Проститутку — погибает и игрок, которого она посетила
                if (
                    hooker
                    and dead_player
                    and dead_player.user_id == hooker.user_id
                    and hooker_target
                    and hooker_target.alive
                ):
                    hooker_target.alive = False
                    if hooker_target not in dead_players:
                        dead_players.append(hooker_target)

                    target_user = await self.bot.fetch_user(hooker_target.user_id)
                    await target_user.send(
    "💀 Вы были убиты этой ночью.\n\n"
    "Причина: этой ночью у вас находилась Проститутка."
                    ) 

                # Проститутка была у жертвы
                if (
                    hooker
                    and hooker.alive
                    and hooker_target
                    and dead_player
                    and dead_player.user_id == hooker_target.user_id
                ):
                    hooker.alive = False
                    if hooker not in dead_players:
                        dead_players.append(hooker)

                    hooker_user = await self.bot.fetch_user(hooker.user_id)
                    await hooker_user.send(
                    "💀 Вы были убиты этой ночью.\n\n"
                    "Причина: вы находились у убитого игрока."
                    )

                if dead_player:
                    for mafia in self.mafia_players():
                        mafia_user = await self.bot.fetch_user(mafia.user_id)
                        await mafia_user.send(
                            "🔫 Убийство прошло успешно.\n\n"
                            f"Жертва: <@{dead_player.user_id}>"
                        )

                doctor = next(
                    (
                        p for p in self.players
                        if p.role.role_type == RoleType.DOCTOR and p.alive
                    ),
                    None
                )

                if (
                    doctor
                    and self.mafia_target is not None
                    and self.mafia_target != self.doctor_target
                ):
                    user = await self.bot.fetch_user(doctor.user_id)
                    await user.send(
                        "❌ Этой ночью вам никого не удалось спасти."
                    )
                    # ==========================
                    # Ход Маньяка
                    # ==========================

                if self.maniac_target is not None:

                    # Доктор спас
                    if self.maniac_target != self.doctor_target:

                        maniac_dead = self.get_player(self.maniac_target)

                        if (
                            maniac_dead
                            and maniac_dead.alive
                        ):

                            maniac_dead.alive = False

                            if maniac_dead not in dead_players:
                                dead_players.append(maniac_dead)

                            user = await self.bot.fetch_user(maniac_dead.user_id)

                            await user.send(
                            "💀 Вы были убиты Маньяком."
                            )
        # ==========================
# Проститутка пришла к Маньяку
# ==========================

        if (
            hooker
            and hooker.alive
            and hooker_target
            and hooker_target.role.role_type == RoleType.MANIAC
        ):

            hooker.alive = False

            if hooker not in dead_players:
                dead_players.append(hooker)

            hooker_user = await self.bot.fetch_user(hooker.user_id)

            await hooker_user.send(
                "💀 Вы были убиты Маньяком.\n\n"
                "Причина: этой ночью вы посетили Маньяка."
            )
        # Сбрасываем ночные действия
        self.mafia_target = None
        self.doctor_target = None
        self.sheriff_target = None
        self.maniac_target = None
        self.maniac_done = False

        self.mafia_done = False
        self.doctor_done = False
        self.sheriff_done = False
        self.hooker_done = False
        self.hooker_target = None

        # Формируем сообщение
        if dead_players:

            victims = "\n".join(
                f"💀 <@{player.user_id}>"
                for player in dead_players
            )

            description = (
                "☀️ Наступило утро.\n\n"
                "Сегодня ночью погибли:\n\n"
                f"{victims}"
            )

        else:

            description = (
                "☀️ Наступило утро.\n\n"
                "🩺 Сегодня ночью никто не погиб."
            )

        await self.update_game_message(
            title="☀️ День",
            description=description,
            color=discord.Color.gold()
        )
        await asyncio.sleep(5)

        # Проверяем победу
        if await self.check_win():
            return

        # Запускаем день
        for player in self.players:

            if player.blocked_by_hooker:
                player.can_vote = False
            else:
                player.can_vote = True

        await self.start_day()

    async def check_win(self):
        return await check_win(self)

    async def start_day(self):

        await self.update_game_message(
            title="☀️ День",
            description=(
                "Обсудите произошедшее.\n\n"
                "⏳ Голосование начнётся через 60 секунд."
            ),
            color=discord.Color.gold()
        )

        await asyncio.sleep(60)

        await self.start_voting()
    async def start_voting(self):

        self.votes.clear()
        self.voted_players.clear()

        await self.update_game_message(
            title="🗳 Голосование",
            description="Все живые игроки выбирают, кого хотят изгнать.",
            color=discord.Color.orange()
        )

        for player in self.alive_players():

            user = await self.bot.fetch_user(player.user_id)

            await user.send(
                "🗳 Выберите игрока для изгнания.",
                view=PlayerSelectView(
                    self,
                    player,
                    "vote_action"
                )
            )

    async def vote_action(
        self,
        interaction,
        actor,
        target_id
    ):
        target = self.get_player(target_id)

        if target is None or not target.alive:
            await interaction.response.send_message(
                "❌ Этот игрок уже мёртв.",
                ephemeral=True
            )
            return
        if not actor.can_vote:
            await interaction.response.send_message(
                "💋 Проститутка провела с вами ночь.\n"
                "Сегодня вы не можете голосовать.",
                ephemeral=True
            )
            return

        if actor.user_id in self.voted_players:
            await interaction.response.send_message(
                "❌ Вы уже проголосовали.",
                ephemeral=True
            )
            return

        self.voted_players.add(actor.user_id)
        self.votes[target_id] = self.votes.get(target_id, 0) + 1

        await interaction.response.send_message(
            "✅ Голос принят.",
            ephemeral=True
        )

        if len(self.voted_players) == len(self.alive_players()):
            await self.finish_voting()

    async def finish_voting(self):

        # Если никто не проголосовал
        if not self.votes:

            await self.start_night()
            return

        max_votes = max(self.votes.values())

        leaders = [
            player_id
            for player_id, votes in self.votes.items()
            if votes == max_votes
        ]

        # Ничья
        if len(leaders) > 1:

            await self.update_game_message(
                title="🗳 Итоги голосования",
                description=(
                    "Голоса разделились поровну.\n\n"
                    "Никто не был изгнан."
                ),
                color=discord.Color.orange()
            )

            await asyncio.sleep(5)
            await self.start_night()
            return

        # Изгнанный игрок
        kicked = self.get_player(leaders[0])

        kicked.alive = False

        await self.update_game_message(
            title="🗳 Итоги голосования",
            description=(
                f"Игрок <@{kicked.user_id}> был изгнан."
            ),
            color=discord.Color.red()
        )

        # Проверяем победу
        if await self.check_win():
            return

        await asyncio.sleep(5)
        for player in self.players:
            player.can_vote = True
            player.blocked_by_hooker = False

        await self.start_night()