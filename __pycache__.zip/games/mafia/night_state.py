from dataclasses import dataclass


@dataclass
class NightState:
    mafia_target: int | None = None
    doctor_target: int | None = None
    sheriff_target: int | None = None
    hooker_target: int | None = None
    maniac_target: int | None = None

    mafia_done: bool = False
    doctor_done: bool = False
    sheriff_done: bool = False
    hooker_done: bool = False
    maniac_done: bool = False

    def reset(self):
        self.mafia_target = None
        self.doctor_target = None
        self.sheriff_target = None
        self.hooker_target = None
        self.maniac_target = None

        self.mafia_done = False
        self.doctor_done = False
        self.sheriff_done = False
        self.hooker_done = False
        self.maniac_done = False