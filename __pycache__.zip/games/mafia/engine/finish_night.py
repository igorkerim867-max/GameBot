from games.mafia.actions.mafia import process as mafia_process
from games.mafia.actions.doctor import process as doctor_process
from games.mafia.actions.hooker import process as hooker_process
from games.mafia.actions.maniac import process as maniac_process

async def finish_night(game):

    # Сброс защиты
    for player in game.players:
        player.protected = False

    # Доктор лечит
    await doctor_process(game)
    
     # Проститутка
    await hooker_process(game)

    # Мафия
    await mafia_process(game)

    # Маньяк
    await maniac_process(game)
    # Остальная логика пока остаётся в game.py