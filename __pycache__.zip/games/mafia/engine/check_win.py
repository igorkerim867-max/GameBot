from games.mafia.roles import Team, RoleType


async def check_win(game):
    alive = game.alive_players()

    mafia = [
        p for p in alive
        if p.role.team == Team.MAFIA
    ]

    civilians = [
        p for p in alive
        if p.role.team == Team.CIVILIAN
        and p.role.role_type != RoleType.MANIAC
    ]

    maniac = next(
        (
            p for p in alive
            if p.role.role_type == RoleType.MANIAC
        ),
        None
    )

    # Победа Маньяка
    if maniac and len(alive) == 1:
        await game.game_over(
            "🔪 Маньяк остался последним в живых!"
        )
        return True

    # Победа Мирных
    if len(mafia) == 0 and maniac is None:
        await game.game_over(
            "👨 Мирные жители уничтожили всех преступников!"
        )
        return True

    # Победа Мафии
    if len(mafia) >= len(civilians) + (1 if maniac else 0):
        await game.game_over(
            "🔫 Мафия захватила город!"
        )
        return True

    return False