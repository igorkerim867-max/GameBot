from games.mafia.roles import RoleType


class PlayerService:

    @staticmethod
    def get_player(game, user_id):
        """Возвращает игрока по ID."""
        for player in game.players:
            if player.user_id == user_id:
                return player
        return None

    @staticmethod
    def alive_players(game):
        """Список всех живых игроков."""
        return [
            player
            for player in game.players
            if player.alive
        ]

    @staticmethod
    def mafia_players(game):
        """Все живые мафиози."""
        return [
            player
            for player in game.players
            if (
                player.alive
                and player.role.role_type in (
                    RoleType.MAFIA,
                    RoleType.DON
                )
            )
        ]

    @staticmethod
    def civilians(game):
        """Все живые мирные роли."""
        return [
            player
            for player in game.players
            if (
                player.alive
                and player.role.role_type not in (
                    RoleType.MAFIA,
                    RoleType.DON
                )
            )
        ]

    @staticmethod
    def has_alive_role(game, role_type):
        """Есть ли живая указанная роль."""
        return any(
            player.alive and player.role.role_type == role_type
            for player in game.players
        )

    @staticmethod
    def find_alive_role(game, role_type):
        """Возвращает первого живого игрока с указанной ролью."""
        for player in game.players:
            if (
                player.alive
                and player.role.role_type == role_type
            ):
                return player

        return None