async def process(game):
    """
    Обработка убийства мафии.
    """

    game.mafia_kill = None

    if game.mafia_target is None:
        return

    target = game.get_player(game.mafia_target)

    if target is None:
        return

    if target.protected:
        game.mafia_saved = True
        return

    game.night_state.mafia_target
    game.night_state.mafia_done = True