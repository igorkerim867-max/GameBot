from games.mafia.roles import RoleType


async def handle_doctor_action(game, interaction, actor, target_id):
    target = game.get_player(target_id)

    if target is None or not target.alive:
        await interaction.response.send_message(
            "❌ Этот игрок уже мёртв.",
            ephemeral=True
        )
        return

    if game.doctor_done:
        await interaction.response.send_message(
            "❌ Вы уже сделали свой ход.",
            ephemeral=True
        )
        return

    game.night_state.doctor_target = target_id
    game.night_state.doctor_done = True

    print(f"Доктор лечит {target_id}")

    await interaction.response.send_message(
        "💉 Выбор сохранён.",
        ephemeral=True
    )

    await game.check_night_finished()