async def process(game):
    """
    Обработка действий Проститутки.
    """

    if game.hooker_target is None:
        return

    target = game.get_player(game.hooker_target)

    if target is None:
        return

    target.can_vote = False
    target.blocked_by_hooker = True

    game.night_state.hooker_target
    game.night_state.hooker_done