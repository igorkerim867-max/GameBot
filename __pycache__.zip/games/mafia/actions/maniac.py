async def process(game):
    """
    Обработка убийства Маньяка.
    """

    game.maniac_kill = None

    if game.night_state.maniac_target is None:
        return

    target = game.get_player(game.night_state.maniac_target)

    if target is None:
        return

    if target.protected:
        return

    game.maniac_kill = target